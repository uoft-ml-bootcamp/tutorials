#!/usr/bin/env python3
"""Sanity tests for participant custom_reward (assert-based, Colab-friendly)."""

from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent


def load_reward_fn():
    spec = importlib.util.spec_from_file_location("custom_reward", SCRIPT_DIR / "custom_reward.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module.custom_reward


def make_state(
    x=0.0,
    y=0.5,
    vx=0.0,
    vy=-0.1,
    angle=0.0,
    ang_vel=0.0,
    left=0.0,
    right=0.0,
) -> np.ndarray:
    return np.array([x, y, vx, vy, angle, ang_vel, left, right], dtype=np.float32)


def test_safe_landing_beats_crash(reward_fn) -> None:
    hover = make_state(y=0.3, vy=-0.05)
    landed_next = make_state(y=0.02, vy=0.0, left=1.0, right=1.0)
    crash_next = make_state(y=0.0, vy=-2.5, left=0.0, right=0.0)

    landing_reward = reward_fn(hover, 0, landed_next, True, False)
    crash_reward = reward_fn(hover, 0, crash_next, True, False)
    assert landing_reward > crash_reward, (
        f"Expected safe landing reward ({landing_reward}) > crash reward ({crash_reward})"
    )


def test_coasting_beats_main_engine_hover(reward_fn) -> None:
    hover = make_state(y=0.8, vy=0.0)
    next_state = make_state(y=0.79, vy=-0.02)
    coast = reward_fn(hover, 0, next_state, False, False)
    main_engine = reward_fn(hover, 2, next_state, False, False)
    assert coast > main_engine, (
        f"Expected coasting reward ({coast}) > main-engine hover reward ({main_engine})"
    )


def test_returns_float(reward_fn) -> None:
    s = make_state()
    ns = make_state(y=0.4)
    out = reward_fn(s, 0, ns, False, False)
    assert isinstance(out, (float, np.floating)), f"Reward must be float, got {type(out)}"


def main() -> None:
    reward_fn = load_reward_fn()
    test_returns_float(reward_fn)
    test_safe_landing_beats_crash(reward_fn)
    test_coasting_beats_main_engine_hover(reward_fn)
    print("All sanity tests passed.")


if __name__ == "__main__":
    main()
