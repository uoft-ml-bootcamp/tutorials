#!/usr/bin/env python3
"""Visual debugger for mapping lander behavior to custom reward values."""

from __future__ import annotations

import argparse
import importlib.util
import pickle
import sys
from pathlib import Path

import gymnasium as gym
import numpy as np

from colab_video import save_and_maybe_display

SCRIPT_DIR = Path(__file__).resolve().parent
VALIDATION_PATH = SCRIPT_DIR / "validation_set.pkl"
ACTION_NAMES = {0: "noop", 1: "left", 2: "main", 3: "right"}


def load_reward_fn():
    spec = importlib.util.spec_from_file_location("custom_reward", SCRIPT_DIR / "custom_reward.py")
    if spec is None or spec.loader is None:
        raise ImportError("Cannot load custom_reward.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.custom_reward


def altitude_bar(y: float, y_min: float, y_max: float, width: int = 12) -> str:
    if y_max - y_min < 1e-6:
        filled = width // 2
    else:
        frac = (y - y_min) / (y_max - y_min)
        filled = int(round(max(0.0, min(1.0, frac)) * width))
    return f"[{'=' * filled}{'.' * (width - filled)}] y={y:+.3f}"


def run_console(trajectory_index: int) -> None:
    with open(VALIDATION_PATH, "rb") as f:
        data = pickle.load(f)
    trajectories = data["trajectories"]
    if trajectory_index < 0 or trajectory_index >= len(trajectories):
        raise IndexError(f"trajectory_index must be in [0, {len(trajectories) - 1}]")

    traj = trajectories[trajectory_index]
    reward_fn = load_reward_fn()
    ys = [float(s["state"][1]) for s in traj["steps"]]
    y_min, y_max = min(ys), max(ys)

    cumulative = 0.0
    print(f"Console replay: validation trajectory {trajectory_index} (tier={traj['tier']})")
    print(f"true_return={traj['true_return']:.2f}  gt_rank={traj['rank']}\n")
    print(f"{'step':>4}  {'action':<5}  {'altitude':<22}  {'reward':>8}  {'cum':>8}")
    print("-" * 55)
    for i, step in enumerate(traj["steps"]):
        r = float(
            reward_fn(
                np.asarray(step["state"], dtype=np.float32),
                int(step["action"]),
                np.asarray(step["next_state"], dtype=np.float32),
                bool(step["terminated"]),
                bool(step["truncated"]),
            )
        )
        cumulative += r
        y = float(step["state"][1])
        bar = altitude_bar(y, y_min, y_max)
        action = ACTION_NAMES.get(int(step["action"]), str(step["action"]))
        print(f"{i:>4}  {action:<5}  {bar:<22}  {r:>8.3f}  {cumulative:>8.3f}")


def run_video(seed: int, policy: str, output: str) -> None:
    print(
        "NOTE: Video mode runs a NEW rollout in Box2D — not an exact replay of offline data.\n"
        "      Use --mode console to inspect exact offline trajectories.",
        file=sys.stderr,
    )
    reward_fn = load_reward_fn()
    env = gym.make("LunarLander-v3", render_mode="rgb_array")
    obs, _ = env.reset(seed=seed)
    frames = [env.render()]
    cumulative = 0.0

    print(f"{'step':>4}  {'action':<5}  {'reward':>8}  {'cum':>8}")
    print("-" * 30)
    for step in range(1000):
        if policy == "random":
            action = env.action_space.sample()
        else:
            action = 0
        next_obs, _env_reward, terminated, truncated, _ = env.step(action)
        r = float(
            reward_fn(
                np.asarray(obs, dtype=np.float32),
                int(action),
                np.asarray(next_obs, dtype=np.float32),
                bool(terminated),
                bool(truncated),
            )
        )
        cumulative += r
        action_name = ACTION_NAMES.get(int(action), str(action))
        print(f"{step:>4}  {action_name:<5}  {r:>8.3f}  {cumulative:>8.3f}")
        frames.append(env.render())
        obs = next_obs
        if terminated or truncated:
            break

    env.close()
    save_and_maybe_display(frames, output)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["console", "video"], default="console")
    parser.add_argument("--trajectory-index", type=int, default=0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--policy", choices=["random", "noop"], default="random")
    parser.add_argument("--output", type=str, default="debug_episode.mp4")
    args = parser.parse_args()

    if args.mode == "console":
        run_console(args.trajectory_index)
    else:
        run_video(args.seed, args.policy, args.output)


if __name__ == "__main__":
    main()
