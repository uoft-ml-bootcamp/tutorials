"""Participant submission: custom reward function for offline trajectory ranking."""

from __future__ import annotations

import numpy as np


def custom_reward(
    state: np.ndarray,
    action: int,
    next_state: np.ndarray,
    terminated: bool,
    truncated: bool,
) -> float:
    """Compute shaped reward for one LunarLander-v3 transition.

    Parameters
    ----------
    state : np.ndarray, shape (8,)
        Pre-step observation.
    action : int
        Discrete action taken (0..3).
    next_state : np.ndarray, shape (8,)
        Post-step observation.
    terminated : bool
        True if episode ended due to landing/crash.
    truncated : bool
        True if episode ended due to time limit.

    Returns
    -------
    float
        Scalar reward for this transition (summed over steps = predicted return).

    Observation layout (LunarLander-v3)
    -----------------------------------
    [0] x position of lander center (horizontal offset from pad; 0 = centered)
    [1] y position / altitude (higher value = higher above ground)
    [2] x velocity (m/s)
    [3] y velocity (m/s; negative = falling)
    [4] angle in radians (0 = upright)
    [5] angular velocity (rad/s; spin rate)
    [6] left leg ground contact (1.0 if touching ground)
    [7] right leg ground contact (1.0 if touching ground)

    Action space (Discrete)
    -----------------------
    0 = do nothing (coast)
    1 = fire left orientation engine
    2 = fire main (bottom) engine
    3 = fire right orientation engine
    """
    # TODO: Replace this starter with your reward engineering.
    # Ideas:
    #   - Reward progress toward pad center (state[0]) and descent (state[1])
    #   - Penalize tilt (state[4]) and angular velocity (state[5])
    #   - Penalize engine use (actions 1, 2, 3) for fuel efficiency
    #   - Add terminal bonus for safe landing, penalty for crash
    _ = (state, action, next_state, terminated, truncated)
    return 0.0
