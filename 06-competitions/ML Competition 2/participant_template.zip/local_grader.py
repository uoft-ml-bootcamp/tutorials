#!/usr/bin/env python3
"""Local validation grader for participants (validation_set.pkl only)."""

from __future__ import annotations

import importlib.util
import pickle
import sys
from pathlib import Path

import numpy as np
from scipy import stats

SCRIPT_DIR = Path(__file__).resolve().parent
VALIDATION_PATH = SCRIPT_DIR / "validation_set.pkl"
REWARD_MODULE_PATH = SCRIPT_DIR / "custom_reward.py"


def predicted_return(steps, reward_fn) -> float:
    total = 0.0
    for step in steps:
        total += float(
            reward_fn(
                np.asarray(step["state"], dtype=np.float32),
                int(step["action"]),
                np.asarray(step["next_state"], dtype=np.float32),
                bool(step["terminated"]),
                bool(step["truncated"]),
            )
        )
    return total


def assign_ranks(returns: np.ndarray) -> np.ndarray:
    return stats.rankdata(-np.asarray(returns, dtype=np.float64), method="average")


def spearman_rank_correlation(gt_ranks: np.ndarray, pred_ranks: np.ndarray) -> float:
    gt = np.asarray(gt_ranks, dtype=np.float64)
    pred = np.asarray(pred_ranks, dtype=np.float64)
    if np.std(gt) < 1e-12 or np.std(pred) < 1e-12:
        return 0.0
    rho, _ = stats.spearmanr(gt, pred)
    if rho is None or np.isnan(rho):
        return 0.0
    return float(rho)


def load_reward_fn():
    spec = importlib.util.spec_from_file_location("custom_reward", REWARD_MODULE_PATH)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {REWARD_MODULE_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.custom_reward


def main() -> None:
    if not VALIDATION_PATH.exists():
        print(f"Missing {VALIDATION_PATH}. Run organizer dataset generation first.")
        raise SystemExit(1)

    with open(VALIDATION_PATH, "rb") as f:
        data = pickle.load(f)

    reward_fn = load_reward_fn()
    trajectories = data["trajectories"]

    pred_returns = []
    true_returns = []
    gt_ranks = []
    for traj in trajectories:
        pred_returns.append(predicted_return(traj["steps"], reward_fn))
        true_returns.append(float(traj["true_return"]))
        gt_ranks.append(float(traj["rank"]))

    pred_arr = np.array(pred_returns, dtype=np.float64)
    true_arr = np.array(true_returns, dtype=np.float64)
    gt_rank_arr = np.array(gt_ranks, dtype=np.float64)
    pred_rank_arr = assign_ranks(pred_arr)
    rho = spearman_rank_correlation(gt_rank_arr, pred_rank_arr)

    print(f"Validation Spearman rho = {rho:.4f}\n")
    print(f"{'idx':>3}  {'tier':>4}  {'true':>8}  {'pred':>8}  {'gt_rank':>7}  {'pred_rank':>9}")
    print("-" * 50)
    for i, traj in enumerate(trajectories):
        print(
            f"{i:>3}  {traj['tier']:>4}  {true_arr[i]:>8.2f}  {pred_arr[i]:>8.2f}  "
            f"{gt_rank_arr[i]:>7.0f}  {pred_rank_arr[i]:>9.1f}"
        )


if __name__ == "__main__":
    main()
