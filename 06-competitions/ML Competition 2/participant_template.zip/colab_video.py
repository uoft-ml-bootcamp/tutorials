"""Colab-safe video helpers: rgb_array frames -> MP4 + notebook display."""

from __future__ import annotations

from pathlib import Path

import imageio.v3 as iio
import numpy as np


def frames_to_mp4(frames: list[np.ndarray], path: str, fps: int = 30) -> str:
    if not frames:
        raise ValueError("No frames to encode.")
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    iio.imwrite(
        out,
        np.stack(frames, axis=0),
        fps=fps,
        codec="libx264",
        macro_block_size=1,
    )
    return str(out.resolve())


def display_in_notebook(mp4_path: str) -> None:
    from IPython.display import Video, display

    display(Video(mp4_path, embed=True))


def in_notebook() -> bool:
    try:
        from IPython import get_ipython

        shell = get_ipython().__class__.__name__
        return shell in {"ZMQInteractiveShell", "Shell"}
    except Exception:
        return False


def save_and_maybe_display(frames: list[np.ndarray], path: str, fps: int = 30) -> str:
    mp4_path = frames_to_mp4(frames, path, fps=fps)
    if in_notebook():
        display_in_notebook(mp4_path)
    else:
        print(f"Wrote video to {mp4_path}")
    return mp4_path
